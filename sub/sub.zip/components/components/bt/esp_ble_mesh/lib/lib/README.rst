ESP-BLE-Mesh Stack Libraries
============================

This repository contains binary libraries supporting Bluetooth Mesh 1.1 Protocol. It is used as a submodule within `Espressif IoT Development Framework`_ (ESP-IDF).

Files in this repository are Copyright (C) 2023 Espressif Systems.

These binary libraries are provided under the same license as the parent esp-idf project - the Apache License 2.0 as provided in the file LICENSE. (The license text refers to this as "Object" form.)

.. _Espressif IoT Development Framework: https://github.com/espressif/esp-idf
